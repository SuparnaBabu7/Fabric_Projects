-- Auto Generated (Do not modify) 52B89CE1F62B04FB986B17F35A10BE2CC951F1744085F254DABBA5052788FEA6
CREATE VIEW Sales.staging_salesdata

AS

SELECT * FROM [DataStagingLakehouse].dbo.[new_salesdata]